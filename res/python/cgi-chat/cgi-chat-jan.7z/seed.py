#!/usr/bin/env python
# -*- coding: utf-8 -*-
#stdblib
import time
import Cookie
import hashlib
import random
#custom libs
import db


def makeOne(usr, data):
    tim = long(time.time()*10000)
    ran = long(random.random()*10000)
    data = str(tim) + str(ran) + usr + data
    data = hashlib.md5(data).hexdigest()
    return data
    

def main(usrname, data):
    d = makeOne(usrname, data)
    cookie = Cookie.SimpleCookie()
    cookie["sessid"] = d
    cookie["sessid"]["domain"]= ".sourceforge.net"
    cookie["sessid"]["path"] = "/"
    authdb = db.AuthDB()
    authdb.setSessID(usrname, d)
    db.closeDB(authdb.con)    
    return cookie
