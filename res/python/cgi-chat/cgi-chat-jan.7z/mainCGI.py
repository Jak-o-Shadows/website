#!/usr/bin/env python
# -*- coding: utf-8 -*-
#stdblib
import cgi
import os
import Cookie
import cgitb
cgitb.enable()
#ext libraries
#custom libs
import db
#cgi stuff
print "Content-type: text/html"
print "Access-Control-Allow-Origin: http://jak-o-shadows.users.sourceforge.net"
print "\n\n"
print ""
print ""


def main():
    method = os.getenv("REQUEST_METHOD")
    if method == "POST":
        post()
    elif method == "GET":
        get()
    else:
        print "NOT A POST OR A GET"
        
        
def get():
    mesDB = db.MessagesDB()
    data = mesDB.last50()
    db.closeDB(mesDB.con)
    data = [[x[1], x[2]] for x in data]
    for i in data:
        print i[0]+ ": " + i[1] +  "<br />"
        
def manualCookieFromString(s):
    cookies = s.split(";")
    #remove trailing and leading spaces
    cookies = [x.lstrip().rstrip() for x in cookies]
    cookDict = {}
    for i in cookies:
        i = i.split("=")
        cookDict[i[0]] = i[1]
    return cookDict
    
def post():
    form = cgi.FieldStorage()
    msg = cgi.escape(form.getfirst("msg"), True)
    mesDB = db.MessagesDB()
    try:
        cstring = os.environ["HTTP_COOKIE"]
        cookDict = manualCookieFromString(cstring)
        sessID = cookDict["sessid"]
        mesDB.logDB(sessID, msg)
        print "message sent"
    except KeyError:
        print "YOU DIDNT' LOGIN"
    db.closeDB(mesDB.con)
    
    
main()