# -*- coding: utf-8 -*-
#database functions
import MySQLdb
import os #for testing environ varialbes

def openDB(dbName):
    """Opens a sqlite3 database connection. returns the connection"""
    f = open("sqladmin", "r")
    pw = f.read().lstrip().rstrip()
    f.close()
    host = "mysql-l"
    user = "l283255admin"
    db = MySQLdb.connect(host=host, user=user, passwd=pw, db=dbName)
    return db
    #con = open("test.db", "a")
    #print "open"
    #con = sqlite3.connect(test + ".db")
    #return db
    
def closeDB(db):
    db.close()
    


class MessagesDB():
    """The database handler for the message database"""
    def __init__(self):
        dbName = "l283255_ogame"
        self.con = openDB(dbName)

    def logDB(self, sessid, msg):
        authDB = AuthDB()
        usr = authDB.getUserBySessID(sessid)
        if usr:
            closeDB(authDB.con)
            cursor = self.con.cursor()
            cursor.execute("INSERT INTO today VALUES(Null, %s, %s)", (usr, msg))
            cursor.close()
            self.con.commit()
        else:
            print "USER NOT AUTHENTICATED"
        #con.execute("INSERT INTO clicks VALUES(Null, ?, ?)", (usr, msg))
        #con.commit()
    
    def last50(self):
        cursor = self.con.cursor()
        cursor.execute("SELECT * FROM today")
        data = cursor.fetchall()
        cursor.close()
        #data = con.read()
        return data
    
class AuthDB():
    """The database handler for the username/password database"""
    def __init__(self):
        dbName = "l283255_ogame"
        self.con = openDB(dbName)
        
        
    def createUser(self, usr, pw):
        cursor = self.con.cursor()
        cursor.execute("INSERT INTO users VALUES (Null, %s, %s, '')", (usr, pw))
        self.con.commit()
        cursor.close()
        return True
        
    def checkPW(self, usr, pw):
        cursor = self.con.cursor()
        cursor.execute("SELECT * FROM users WHERE usr = %s", (usr,))
        userData = cursor.fetchone()
        cursor.close()

        if userData:
            if userData[2] == pw:
                return True
            else:
                return False
        else:
            return False
            

    def setSessID(self, usr, sessID):
        cursor= self.con.cursor()
        cursor.execute("UPDATE users SET sessID=%s WHERE usr=%s", (sessID, usr))
        self.con.commit()
        cursor.close
        
        
    def getUserBySessID(self, sessID):
        cursor = self.con.cursor()
        cursor.execute("SELECT * FROM users WHERE sessID=%s", (sessID,))
        data = cursor.fetchone()
        cursor.close()
        if data:
            usr = data[1]
            return usr
        else:
            return False
            
    def checkUserExists(self, usr):
        cursor = self.con.cursor()
        cursor.execute("SELECT * FROM users WHERE usr=%s", (usr,))
        data = cursor.fetchone()
        cursor.close()
        if data:
            return True
        else:
            return False
        