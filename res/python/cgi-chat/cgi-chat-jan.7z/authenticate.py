#!/usr/bin/env python
# -*- coding: utf-8 -*-
#login file
#gives you a unique cookie, set to session expire, when you provide the login
#stdblib
import cgi
import cgitb
cgitb.enable()
import urllib
import os
#custom libs
import db
import seed
#cgi stuff
print "Content-type: text/html"
print "Access-Control-Allow-Origin: *"#http://jak-o-shadows.users.sourceforge.net"


def finSTDHeaders():
    print "\n\n"
    print ""
    print ""

def main():
    form = cgi.FieldStorage()
    usrname = cgi.escape(form.getfirst("usr"))
    pw = cgi.escape(form.getfirst("pw"))
    authDB = db.AuthDB()
    authed = authDB.checkPW(usrname, pw)
    db.closeDB(authDB.con)
    if authed:
        status = "Authenticated: " + usrname + "\n Redirecting..."
        print seed.main(usrname, os.environ["HTTP_USER_AGENT"])
        print finSTDHeaders()
        #args = {"usr": usrname, "data": os.environ["HTTP_USER_AGENT"]}
        #addr = "http://laptimer.sourceforge.net/cgi-bin/seed.py?" + urllib.urlencode(args)
        addr = "http://laptimer.sourceforge.net/ogame/page.html"
        code = """<meta http-equiv="refresh" content="1;URL='"""+addr+"""'">"""
        status += code
    else:
        status = "Incorrect Username/Password"
    print status


main()
