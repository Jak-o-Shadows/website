#!/usr/bin/env python
# -*- coding: utf-8 -*-
import cgi
import db
import cgitb
cgitb.enable()
print "Content-type: text/html\n\n"
print ""
print ""
def start():
    f = open("test.db", "w")
    f.close()
    """
    con = sqlite3.connect("test" + ".db")
    con.execute("DROP TABLE IF EXISTS clicks")
    con.execute("CREATE TABLE clicks(id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, msg TEXT)")
    con.commit()
    con.close()"""
    
def doActions(action):
    action = action.lstrip().rstrip()
    if action=="start":
        print "starting"
        start()
        print "started"
    else:
        print "not a valid command"

def register(usr, pw):
    authDB = db.AuthDB()
    status = ""
    if not authDB.checkUserExists(usr):
        #we have a new user! hooray!
        if authDB.createUser(usr, pw):
            status = "User created successfully"
            addr = "http://laptimer.sourceforge.net/ogame/login.html"
            code = """<meta http-equiv="refresh" content="1;URL='"""+addr+"""'">"""
            status += code
        else:
            status = "Failed upon creating user"
    else:
        status = "Username already taken"
    return status
    

def main():
    form = cgi.FieldStorage()
    usrname = cgi.escape(form.getfirst("usr"))
    usrname = usrname.rstrip().lstrip() #so no fancy enders game type tricks can be played
    pw = cgi.escape(form.getfirst("pw"))
    pw = pw.rstrip().lstrip()
    action = form.getfirst("action")
    if action == "register":
        register(usrname, pw)
    else:
        pass
        """
        f = open("admin", "r") #admin file is set non-readable to "others"
        password = f.read().lstrip().rstrip()
        f.close()
        if pw == password:
            doActions(action)
        else:
            print "NOT AUTHENTICATED"
        """
        
main()