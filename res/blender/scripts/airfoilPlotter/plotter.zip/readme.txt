"""A script by Fake (http://fake.yolasite.com). If you did not get it from there, please email me at simfake[dot]mapping[at]gmail[dot]com.

It takes a series of coordinates, as almost from http://www.ae.illinois.edu/m-selig/ads.html download the .dat file for the airfoil you want
    
To get it into blender, just remove the junk lines before the coordinates, and the blank line between the sets of coordinates. 
Then you have to highlight sets of vertices that are next to each other (just 2 at a time) and then press f. It doesn't really take very long.

To change the file, just change the variable named file to what you want. The file has to be in the same folder as this saved blend (Just copy this blend).

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Released 2009 by Fake (http://fake.yolasite.com)

Works with 2.49 onwards on Windows 7. No reason for it not to work with anything else though.






To fix the read error. Just type out an aboslute path to the file. If you're using windows, you'll have to use forward slashes like *nix and the internet. 
"""